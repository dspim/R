slide <- function() {
  utils::browseURL(system.file("slide/index.html", package = .packageName))
}