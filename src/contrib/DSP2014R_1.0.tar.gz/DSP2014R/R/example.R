long_execute <- function() {
  for(i in 1:1000) Sys.sleep(1)
}

