---
title       : R 語言探索之旅
subtitle    : 
author      : Wush Wu
job         : 
framework   : io2012        # {io2012, html5slides, shower, dzslides, ...}
highlighter : highlight.js  # {highlight.js, prettify, highlight}
hitheme     : tomorrow      # 
widgets     : [mathjax]            # {mathjax, quiz, bootstrap}
mode        : selfcontained # {standalone, draft}
knit        : slidify::knit2slides
--- &twocol



## 關於講者

*** =left

- 台灣大學電機工程學研究所博士生
- Taiwan R User Group 共同創辦人
- 資料科學愛好者年會 - 課程總召

*** =right

<img src="assets/img/wush.jpg" style="max-width:100%;max-height:100%;" />

--- .segue .dark

## 為什麼R 這麼受歡迎？

--- &vcenter

## R 來自世界上最專業的統計學家

<center><img src="assets/img/statician_10521919-655x280.jpg" class="fit100" /></center>

圖片來源： <http://myfootpath.com/careers/engineering-careers/statistician-careers/>

---

## R 可以輸出高品質的視覺化

<img src="assets/img/flights_sml.jpg" style="max-width:100%;max-height:100%;" />

取自<http://www.r-bloggers.com/mapping-the-worlds-biggest-airlines/>

--- &vcenter

## R 有驚人彈性和潛力

<center><img src="assets/img/fig_10_cran1.png" style="max-width:75%;max-height:75%;" /></center>

取自 <http://r4stats.com/2013/03/19/r-2012-growth-exceeds-sas-all-time-total/>

--- &vcenter

## R 很容易和其他工具整合

<center>
![plot of chunk r-integration](assets/fig/r-integration.png) 
</center>

--- &vcenter

## R 很容易擴充和客製化

<center><img src="assets/img/t134_3ca_lg.jpg" style="max-width:100%;max-height:100%;" /></center>
來源：<http://img.diynetwork.com/DIY/2003/09/18/t134_3ca_med.jpg>

--- &vcenter .largecontent

## 今天的目標

### 環境設定

- 建立可以使用R 的環境
- 了解R 的使用界面

### 學習R 語言

- 透過實際的範例學習R 語言
    - 讀取資料
    - 選取資料
    - 敘述統計量與視覺化
- 利用實例來傳授學習的心法

--- &vcenter .largecontent

## 今天的目標

### 關於未來

- 如何繼續R 的旅程

--- .segue .dark

## 工欲善其事，必先利其器

--- &twocol .largecontent

## 安裝 R 與 Rstudio

### 請參考現場示範或以下影片

--- &vcenter .largecontent

## Rstudio 界面

- 程式碼編輯區
- 命令列區
- 其他資訊區
- 檔案系統區

--- &vcenter .largecontent

## 熟悉R 和Rstudio的界面

- 了解輸入
- 了解輸出
- 中斷程式

--- &vcenter .largecontent

## 熟悉R 和Rstudio的界面 - 請你跟我這樣做

### 命令列區

- 注意最左下腳的符號是`>`
- 輸入`"hello world"`後按下Enter，檢查螢幕輸出（記得加上引號）
- 輸入`1 + 1`後按下Enter，檢查螢幕輸出，注意有無引號
- 輸入`1 + `後按下Enter，檢查螢幕輸出，注意最左下角的開頭變成`+`
- 按下Ctrl + C或ESC，檢查哪一個按鈕會讓左下角回復成`>`開頭

--- &vcenter .largecontent

## 熟悉R 和Rstudio的界面 - 請你跟我這樣做

### 命令列區

- 在新的一行命令列區輸入`he`之後按下Enter
- 在新的一行命令列區輸入`he`之後按下tab

--- &vcenter .largecontent

## 熟悉R 和Rstudio的界面 - 請你跟我這樣做

### 程式碼編輯區

- 建立新的R Script檔案
- 在第一行輸入`he`隻後按下Ctrl + Enter後，觀察命令列區
- 利用滑鼠點選`he`後的位置，確認游標閃爍的位置在`he`之後，按下tab

--- .segue .dark

## R 的擴充功能

--- 

## [CRAN Task Views](http://cran.r-project.org/web/views/)

<img src="assets/img/CRAN-Task-Views.png" style="max-width:100%;max-height:100%;" />

--- &vcenter .largecontent

## 套件的安裝

### UI

請見Demo

### 命令列


```r
install.views("topic-name")
install.packages("pkg-name", repos = "來源")
```

--- &vcenter .largecontent

## 小挑戰

### 套件安裝

- 利用UI安裝`RSQLite`
- 利用命令列從`"http://dspim.github.io/R"`上安裝`"DSP2014R"`，輸入的值前後請加上引號
    - 安裝完畢之後，請輸入`library(DSP2014R);slide()`來在瀏覽器之中打開投影片

*** =pnotes

`install.packages("DSP2014R", repos = "http://dspim.github.io", type = "source")`

--- .dark .segue

## 讓我們來說R 語

--- &twocol .largecontent

## 敘述句(expression)

*** =left


```r
"1;2;3;"
```

```
## [1] "1;2;3;"
```

```r
1;2;3;
```

```
## [1] 1
```

```
## [1] 2
```

```
## [1] 3
```

*** =right

- 敘述句以`;`或`斷行`(輸入Enter)作結尾
- R 會把單引號`'`或雙引號`"`所包覆的敘述當成字串
- 沒有完成的敘述句，命令列的開頭會變成`+`
- 可以用Ctrl + C 中斷敘述句

--- &vcenter .largecontent

## 註解

- `#`之後的程式碼會被當成註解
    - R 會完全忽略註解
    - 註解的功用是增加程式碼的可讀性


```r
1;2;#3
```

```
## [1] 1
```

```
## [1] 2
```

--- &twocol .largecontent

## 敘述句與數值運算

*** =left


```r
1 + 1
```

```
## [1] 2
```

```r
1 + 2 - 1
```

```
## [1] 2
```

```r
(1 + 1) * 2
```

```
## [1] 4
```

```r
2.5e3
```

```
## [1] 2500
```

*** =right

- 敘述句可以運算出一個R 物件
- 運算的順序符合先乘除後加減，括號最優先
- 中間有`e`的數值代表要再乘以10的冪次方

--- &twocol .largecontent

## 變數與賦值 `<-`或`=`

*** =left


```r
One
```

```
## Error: 找不到物件 'One'
```

```r
One <- 1
One
```

```
## [1] 1
```

```r
Two = "2"
Two
```

```
## [1] "2"
```

*** =right

### 賦值

<center>
<img src="assets/img/assign-missing.png" style="max-width:50%;max-height:50%;" />
</center>

$$\Downarrow$$

<center>
<img src="assets/img/assign-linking.png" style="max-width:50%;max-height:50%;" />
</center>

--- &twocol .largecontent

## 向量

*** =left


```r
1:3
```

```
## [1] 1 2 3
```

```r
c(1, 2, 3) + 1
```

```
## [1] 2 3 4
```

```r
1:3 * 2
```

```
## [1] 2 4 6
```

*** =right

- 利用`c`和建立向量
- 利用`:`建立序列
- 運算是向量式的

<center><img src="assets/img/vectorize-plus-before.png" style="max-width:50%;max-height:50%;" /></center>
$$\Downarrow$$
<center><img src="assets/img/vectorize-plus-after.png" style="max-width:50%;max-height:50%;" /></center>

--- &vcenter .largecontent

## 呼叫函數

### 請在Rstudio的命令列區進行以下操作

- 輸入`c`，按下tab
    - 自動完成：列出所有`c`開頭的函數
    - 列出函數的說明文件
- 清空命令列，輸入`?c`後按下Enter
- 清空命令列，輸入`c`後按下Enter

--- &vcenter .largecontent

## 小挑戰

### 請利用`+`、`-`、`*`或`/`來回答：

```r
# 社會服務業自民國87至民國91年的年度用電量（度）
power1 <- c(6097059332, 6425887925, 6982579022, 7323992602.53436, 7954239517) 
# 製造業自民國87至民國91年的年度用電量（度）
power2 <- c(59090445718, 61981666330, 67378329131, 66127460204.6482, 69696372914.6949) 
```

- 計算各年度製造業的用電量是社會服務業的多少倍?

*** =pnotes

`power2 / power1`

--- .segue .dark

## R 的資料結構

--- &twocol .largecontent

## 數值系統的分類

*** =left

- 名目資料(nomial)
- 順序資料(ordinal)
- 區間資料(interval)
- 比例資料(ratio)

*** =right


|資料衡量尺度 |變數形態 |特性   |
|:------|:----|:----|
|名目資料   |質化   |表示類別 |
|順序資料   |質化   |優先順序 |
|區間資料   |量化   |大小距離 |
|比例資料   |量化   |比值   |

--- &vcenter .largecontent

## 量化的資料

- 用電度數
- 身高、體重、成績
- 時間

--- &vcenter .largecontent

## R 的數值形態

- 數值形態
    - 整數`1L`
    - 實數`1.5`


```r
99L;99.5
```

```
## [1] 99
```

```
## [1] 99.5
```

--- &vcenter .largecontent

## R 的特殊數值形態

- 時間


```r
Sys.time()
```

```
## [1] "2014-12-08 22:58:16 CST"
```

```r
ISOdatetime(year = 1970, month = 1, day = 1, 
            hour = 0, min = 0, sec = 0)
```

```
## [1] "1970-01-01 CST"
```

--- &vcenter .largecontent

## 量化的資料

- 產業分類
- 班別

--- &vcenter .largecontent

## R 的類別形態

- 字串
- 類別


```r
c("011", "012");factor(c("三年甲班", "三年乙班", "三年甲班"))
```

```
## [1] "011" "012"
```

```
## [1] 三年甲班 三年乙班 三年甲班
## Levels: 三年甲班 三年乙班
```

--- &vcenter .largecontent

## 查詢變數的類別


```r
x <- 1:3
class(x);mode(x)
```

```
## [1] "integer"
```

```
## [1] "numeric"
```

```r
x <- c("1", "2", "3")
class(x);mode(x)
```

```
## [1] "character"
```

```
## [1] "character"
```

--- &vcenter .largecontent

## 資料形態的轉換 - 將數值轉換為類別

### 直接轉換


```r
x <- c(1, 2, 3, 2, 3, 2, 1)
as.character(x) # 字串
```

```
## [1] "1" "2" "3" "2" "3" "2" "1"
```

```r
factor(x) # 類別
```

```
## [1] 1 2 3 2 3 2 1
## Levels: 1 2 3
```

--- &vcenter .largecontent

## 資料形態的轉換 - 將數值轉換為類別

### 分級


```r
x <- c(75, 81, 82, 76, 91, 92)
cut(x, breaks = c(70, 80, 90, 100))
```

```
## [1] (70,80]  (80,90]  (80,90]  (70,80]  (90,100] (90,100]
## Levels: (70,80] (80,90] (90,100]
```

--- &vcenter .largecontent

## 資料形態的轉換 - 將字串轉換為數值

### 直接轉換


```r
x <- c("1", "2", "3", "2", "a")
as.numeric(x)
```

```
## Warning: 強制變更過程中產生了 NA
```

```
## [1]  1  2  3  2 NA
```

- `NA`代表Not available，代表著**missing value**

--- &vcenter .largecontent

## 資料形態的轉換 - 資料清理

### 民國80年至82年的國民生產毛額

<pre><code style="text-align: center;">
百萬元
5,023,763
5,614,679
6,205,338
</code></pre>


```r
gdp <- c("5,023,763", "5,614,679", "6,205,338")
as.numeric(gsub(",", "", gdp))
```

```
## [1] 5023763 5614679 6205338
```

---

## 小挑戰

請問這份「各年度產業別用電資料」的各欄類別為何？


|label |name  | year|     power|
|:-----|:-----|----:|---------:|
|      |農藝及園藝 |   87| 113584956|
|011   |農藝及園藝 |   88| 122010866|
|011   |農藝及園藝 |   89| 139061996|
|011   |農藝及園藝 |   90| 143103986|
|011   |農藝及園藝 |   91| 149192893|
|011   |農藝及園藝 |   92| 176680799|

--- &vcenter .largecontent

## `summary` 指令


```r
data(power, package = "DSP2014R")
summary(power)
```

```
##     label               name                year           power         
##  Length:4608        Length:4608        Min.   : 87.0   Min.   :0.00e+00  
##  Class :character   Class :character   1st Qu.: 90.8   1st Qu.:2.71e+07  
##  Mode  :character   Mode  :character   Median : 94.5   Median :1.43e+08  
##                                        Mean   : 94.5   Mean   :1.15e+09  
##                                        3rd Qu.: 98.2   3rd Qu.:6.85e+08  
##                                        Max.   :102.0   Max.   :1.05e+11
```

- 根據資料形態的不同，函數的輸出結果也會不同


--- .segue .dark

## 資料的讀取

--- &vcenter .largecontent

## 讀取整理過後的表格檔案

```
"產業代號（第六版）","產業名稱","年度（民國）","用電量（度）"
"","農藝及園藝",87,113584956
"011","農藝及園藝",88,122010866
"011","農藝及園藝",89,139061996
"011","農藝及園藝",90,143103985.905191
```


```r
path <- system.file("opendata/power/power.csv", package = "DSP2014R");path
```

```
## [1] "/Users/wush/Library/R/3.1/library/DSP2014R/opendata/power/power.csv"
```

```r
src <- readLines(con = path, n = 5)
power <- read.table(file = path, header = TRUE, sep = ",");head(power)
```

```
##   產業代號.第六版.   產業名稱 年度.民國. 用電量.度.
## 1                  農藝及園藝         87  113584956
## 2              011 農藝及園藝         88  122010866
## 3              011 農藝及園藝         89  139061996
## 4              011 農藝及園藝         90  143103986
## 5              011 農藝及園藝         91  149192893
## 6              011 農藝及園藝         92  176680799
```

*** =pnotes

- 注意：有些參數是字串，有些參數是數值
- TRUE/FALSE代表布林值

--- &vcenter .largecontent

## 常見的讀取錯誤

### 路徑錯誤


```r
path <- "wrong_path"
power <- read.table(file = path, header = TRUE, sep = ",")
```

```
## Warning: 無法開啟檔案 'wrong_path' ：No such file or directory
```

```
## Error: 無法開啟連結
```

- 絕對路徑
    - 確認檔案是否存在
- 相對路徑
    - 利用`getwd`了解R 當下的路徑位置

--- &vcenter .largecontent

## 常見的讀取錯誤

### 格式錯誤


```r
path <- system.file("opendata/power/power.csv", package = "DSP2014R")
power <- read.table(file = path, header = TRUE, sep = "1")
```

```
## Error: more columns than column names
```

- 利用其他編輯器確認分隔符號
- 確認每列的資料的欄位是正確的
    - 必要時，請用其他文件編輯器校正欲讀取的檔案

--- &vcenter .largecontent

## 常見的讀取錯誤

### 編碼錯誤


```r
path <- switch(Sys.info()[["sysname"]], 
       system.file("opendata/power/power-big5.csv", package = "DSP2014R"))
power <- read.table(file = path, header = TRUE, sep = ",")
```

```
## Error: 無效的多位元組字串於
## '<b2><a3><b7>~<a5>N<b8><b9><a1>]<b2>Ĥ<bb><aa><a9><a1>^'
```

- 查詢檔案的編碼
    - 常見的中文編碼有`utf-8`和`big5`
    - 利用其他工具做編碼的轉換(推薦, Windows 上建議安裝[Rtools](http://cran.csie.ntu.edu.tw/bin/windows/))，可使用`iconv`和`file`兩個工具
    - 讀取時套上`file`函數指定編碼（較不推薦）

*** =pnotes

- `help("switch")`
    - 根據第一個參數的結果，決定後續的行為


```r
path <- switch(Sys.info()[["sysname"]], 
       system.file("opendata/power/power-big5.csv", 
                   package = "DSP2014R"))
encoding <- switch(Sys.info()[["sysname"]], 
       "big5")
power <- read.table(file = file(path, encoding = encoding), 
                    header = TRUE, sep = ",")
```

--- &vcenter .largecontent

## 小練習

### 請問這個錯誤訊息代表哪一種讀取錯誤？

```
Error: more columns than column names
```

--- &vcenter .largecontent

## 校正欄位名稱


```r
power2 <- edit(power)
colnames(power2)
colnames(power2) <- c("label", "name", "year", "power")
```

--- &vcenter .largecontent

## 範例

- 自[UCI Machine Learning Repository](http://archive.ics.uci.edu/ml/)
    1. 下載資料
    1. 讀取資料
    1. 校正欄位名稱

--- &vcenter .largecontent

## 小練習

### 請自[UCI Machine Learning Repository](http://archive.ics.uci.edu/ml/)練習其他資料

--- &vcenter

## 讀取資料庫

### SQLite


```r
library(RSQLite)
```

```
## Loading required package: DBI
```

```r
path <- system.file("sqlite/example.db", package = "DSP2014R")
db <- dbConnect("SQLite", path)
dbListTables(db)
```

```
## [1] "gdp"   "power"
```

```r
power <- dbReadTable(db, "power")
dbDisconnect(db)
```

```
## [1] TRUE
```

--- &vcenter .largecontent

## 小挑戰

### 自範例的資料庫中讀取"gdp"表格

--- &vcenter .largecontent

## 未來的學習清單

### 各式資料庫的連接

- SQL Database: `RMySQL`, `RPostgreSQL`, `ROracle`, `RJDBC`, `RODBC`
- No SQL Database: `rmongodb`, `rredis`
- 讀取XML和網頁資料
    - `XML`套件和XPath
- 讀取json資料
    - `RJSONIO`套件

--- .segue .dark

## 資料的選取

--- &vcenter .largecontent

## 布林運算

- `>` `<` `>=` `<=` `==` `!=`


```r
1 > 2;1 <= 2
```

```
## [1] FALSE
```

```
## [1] TRUE
```

```r
"A" == "A";"A" != "A"
```

```
## [1] TRUE
```

```
## [1] FALSE
```

--- 

## 向量的選取

### 坐標


```r
x <- 1:5; x[2:3]
```

```
## [1] 2 3
```

### 布林


```r
x <- 1:5; x > 3; x[x > 3]
```

```
## [1] FALSE FALSE FALSE  TRUE  TRUE
```

```
## [1] 4 5
```

--- &vcenter .largecontent

## 多重條件

### 且：`&`

`布林運算結果1 & 布林運算結果1`

### 或：`|`

`布林運算結果1 | 布林運算結果1`

--- &vcenter .largecontent

## 小挑戰


```r
# 社會服務業自民國87至民國91年的年度用電量（度）
power1 <- c(6097059332, 6425887925, 6982579022, 7323992602.53436, 7954239517) 
# 製造業自民國87至民國91年的年度用電量（度）
power2 <- c(59090445718, 61981666330, 67378329131, 66127460204.6482, 69696372914.6949) 
```

- 運用index從`power1`中選取第88年和第90年的年度用電量。結果應該為：
    
    ```
    ## [1] 6.426e+09 7.324e+09
    ```
- 運用布林運算自`power2`中選出，製造業超過社會服務業9.5倍的用電年度的用電量。結果應該為：
    
    ```
    ## [1] 5.909e+10 6.198e+10 6.738e+10
    ```

--- &vcenter .largecontent

## 表格的選取


```r
data(power, package = "DSP2014R")
power[1, 2]
```

```
## [1] "農藝及園藝"
```

<img src="assets/img/table_selection.png" style="max-width:100%;max-height:100%;" />

--- &vcenter .largecontent

## 欄的選取


```r
head(power)
```

```
##   label       name year     power
## 1       農藝及園藝   87 113584956
## 2   011 農藝及園藝   88 122010866
## 3   011 農藝及園藝   89 139061996
## 4   011 農藝及園藝   90 143103986
## 5   011 農藝及園藝   91 149192893
## 6   011 農藝及園藝   92 176680799
```

```r
head(power[["name"]]) # head(power$name)
```

```
## [1] "農藝及園藝" "農藝及園藝" "農藝及園藝" "農藝及園藝" "農藝及園藝"
## [6] "農藝及園藝"
```

--- &vcenter .largecontent

## 範例

### 選取資訊服務業的歷年用電資料

1. 自`power`選取`name`
2. 利用布林運算，把1.的結果和`"資訊服務業"`比較
3. 利用2.的結果選取power的列


```r
x1 <- power[["name"]] # power$name
x2 <- x1 == "資訊服務業"
x3 <- power[x2,]
head(x3)
```

```
##      label       name year    power
## 3777    75 資訊服務業   87 30850085
## 3778    75 資訊服務業   88 30701889
## 3779    75 資訊服務業   89 35680295
## 3780    75 資訊服務業   90 56497904
## 3781    75 資訊服務業   91 74969030
## 3782    75 資訊服務業   92 86085087
```

---

## 小挑戰

### 請選取「資訊服務業」第89年度的用電量

1. 自`power`選取`name`
2. 利用布林運算，把1.的結果和`"資訊服務業"`比較
3. 自`power`選取`year`
4. 利用布林運算，把3.的結果和89比較
5. 利用布林運算，取得同時滿足2.和4.的結果（且）
6. 利用5.的結果選取power的列

*** =pnotes


```r
x1 <- power[["name"]]
x2 <- x1 == "資訊服務業"
x3 <- power[["year"]]
x4 <- x3 == 89
x5 <- x2 & x4
x6 <- power[x5,]
x6
```

--- &vcenter .largecontent

## 指令的壓縮

- 請大家學習「被壓縮的程式碼」該如何解讀
    - 掌握運算符號的運算順序


```
##      label       name year    power
## 3779    75 資訊服務業   89 35680295
```

--- .segue .dark

## 資料的探索

--- &vcenter .largecontent

## 探索一個變數

### 量化數據

- 敘述統計量：`mean`、`sd`、`median`、`quantile`
- 繪圖看分佈：`density`

### 質化數據

- 分佈表格：`table`

--- &vcenter 

## 利用說明文件了解函數內容

### 範例：學習`mean`的用法

- 閱讀說明文件
    
    ```r
    ?mean
    ```
- 嘗試範例
    
    ```r
    example(mean)
    ```
- 自動完成
    - 在命令列輸入`mena(`後按下`tab`

--- &vcenter .largecontent

## 探索一個量化變數

### 挑戰：學習`sd`的用法

--- &vcenter .largecontent 

## 探索一個量化變數

### 挑戰：選取<b>出版業合計</b>的歷年用電消耗量資料

<br/>

### 範例：使用`mean`求<b>出版業合計</b>的歷年用電平均值

<br/>

### 挑戰：使用`sd`求<b>出版業合計</b>的歷年用電標準差

*** =pnotes

1. 選取<b>出版業合計</b>的歷年用電消耗量資料
2. 在`mean`中利用1.的結果
3. 在`sd`中利用1.的結果

--- &vcenter .largecontent

## 探索一個質化變數

1. 選取電力資料中所有的標籤，存成`label`變數
2. 學習`table`的用法
    - `?table`
    - `example(table)`
3. 利用`table`觀察標籤的個數

*** =pnotes


```r
data(power, package = "DSP2014R")
label <- power[["label"]]
# ?table
# table(label)
```

--- &vcenter .largecontent

## 探索變數間的關係

- `ftable`：質化 v.s. 質化
- bar chart：質化 v.s. 量化
- scatter plot： 量化 v.s. 量化

--- &vcenter .largecontent

## 探索質化變數與質化變數的關係


```r
?ftable
example(ftable)
```

```
ftable> ## Start with a contingency table.
ftable> ftable(Titanic, row.vars = 1:3)
                   Survived  No Yes
Class Sex    Age                   
1st   Male   Child            0   5
             Adult          118  57
      Female Child            0   1
             Adult            4 140
```

--- &vcenter .largecontent

## 描述資料間的關係：`formula`物件

### 變數之間的因果關係

<img src="assets/img/500px-Ishikawa_Fishbone_Diagram.svg.png" style="max-width:100%;max-height:100%;" />

出處：<http://en.wikipedia.org/wiki/Causality>

--- &vcenter .largecontent

## 描述資料間的關係：`formula`物件

`Column Name 1 ~ Column Name 2 + ...`

- 給定一個表格
    - `Column Name 1`是代表結果資料的欄位名稱
    - `Column Name 2`是代表原因資料的欄位名稱
    - `...`表示原因不止一個欄位
- formula中的欄位名稱不用加上雙引號


```r
ftable(Survived ~ Sex, Titanic)
ftable(Survived ~ Sex + Class, Titanic)
```

--- .dark .segue

## R 的基礎繪圖

--- &vcenter .largecontent

## 繪圖之前的整理資料：質化 v.s. 量化


```r
data(power, package = "DSP2014R")
# unique(power$label)
label <- power$label
label.level1 <- label %in% paste0(LETTERS, ".")
year.100 <- power[["year"]] == 100
power.level1.100 <- power[label.level1 & year.100,]
```

- 同時選取字母開頭<b>且</b>年度為100的資料
- 學習功能函數和內定變數: `unique`, `%in%`, `paste0`, `LETTERS`

--- &vcenter .largecontent

## barplot


```r
barplot(height = power.level1.100$power, names.arg = power.level1.100$label)
```

![plot of chunk barplot](assets/fig/barplot.png) 

--- &vcenter largecontent

## 繪圖之前的整理資料：量化 v.s. 量化


```r
data(power, package = "DSP2014R")
label <- power$label
power.91 <- power[label == "91",]
```

- 選取`label`為`"91"`的列

--- &vcenter .largecontent

## scatter plot


```r
plot(power ~ year, power.91)
```

![plot of chunk power.91.scatter_plot](assets/fig/power.91.scatter_plot.png) 

- 原因在x軸，結果在y軸

--- &vcenter .largecontent

## 圖形的美化

### Maker精神：雕圖

- 學習`par`中的參數
- 複刻別人的code

### 站在巨人的肩膀上

- 使用如ggplot2或ggvis套件

--- &twocol

## [Watercolor Plot](http://www.nicebread.de/visually-weighted-watercolor-plots-new-variants-please-vote/)

*** =left

<center>
![plot of chunk cars](assets/fig/cars.png) 
</center>

*** =right

<center>
![plot of chunk cars-watercolor](assets/fig/cars-watercolor.png) 
</center>

--- &vcenter .largecontent

## 清楚的畫圖

- 範圍：`xlim`, `ylim`
- 標題：`main`, `xlab`, `ylab`
- 顏色、圖樣：`color`, `pch`
- 坐標軸：`axis`
- 圖說：`legends`
- 數學符號：`help("plotmath")`

--- &vcenter .largecontent

## 學習圖的參數 - 以pch為例


```r
help("pch")
example(pch)
```


--- &vcenter


```r
# par(family = "STKaiti") # for OS X
plot(power ~ year, power.91, main = "歷年公務機構及國訪事業合計用電量",
     xlab = "年(民國)", ylab = "用電量（十億度）", yaxt = 'n', pch = 2)
axis(2, at = c(2, 2.2, 2.4, 2.6) * 1e9, label = c("2.0", "2.2", "2.4", "2.6"))
```

![plot of chunk power.91-clearer.fig](assets/fig/power.91-clearer.fig.png) 

--- .dark .segue

## 圖表的輸出

--- &vcenter .largecontent

## 輸出圖片

- Rstudio UI
- `savePlot`
- `bmp`、`png`、`jpeg`或`tiff`

--- &vcenter .largecontent

## 輸出表格

- `write.csv`
- `xtable`套件

--- &vcenter .largecontent

## R markdown 火力展示

- 請見現場live demo

--- .segue .dark

## 更強大的繪圖功能示例

--- &twocol

## ggplot2

*** =left

![plot of chunk ggplot2-left](assets/fig/ggplot2-left.png) 

*** =right

![plot of chunk ggplot2-right](assets/fig/ggplot2-right.png) 

--- &vcenter

## shiny

<http://shiny.rstudio.com/gallery/>

--- .dark .segue

## 總結

--- &vcenter .largecontent

## 今天的目標

### 環境設定

- 建立可以使用R 的環境
- 了解R 的使用界面

### 學習R 語言

- 透過實際的範例學習R 語言
    - 讀取資料
    - 選取資料
    - 敘述統計量與視覺化
- 利用實例來傳授學習的心法

--- &vcenter .largecontent

## 掌握心法後，如何自行利用R 解決問題

- 了解自己的需求
- 詢問關鍵字與函數
    - 歡迎來信 <wush978@gmail.com> 或其他教師
    - 多多交流
        - [Taiwan R User Group](http://www.meetup.com/Taiwan-R)，mailing list: <Taiwan-useR-Group-list@meetup.com>
        - ptt R_Language版
        - [R軟體使用者論壇](https://groups.google.com/forum/#!forum/taiwanruser)
    - `sos`套件，請見Demo
- 利用今日習得的心法掌握函數用法

--- &vcenter .largecontent

## 你喜歡R 嗎？

- R 是由一群來自世界上的志工貢獻而成的
- 你覺得R 有不好用的地方嗎？
    - 歡迎聯絡我，讓我們一起來貢獻，改進R 的使用體驗

<img src="assets/img/Rlogo.jpg" width="225" height="171"/>

--- &vcenter .largecontent

## DSP 提供的未來課程

--- &vcenter .largecontent

## Q&A

---
