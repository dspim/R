/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/Regular/BlockElements.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS.STIXGeneral,{9600:[910,-304,1213,0,1213],9604:[303,303,1213,0,1213],9608:[910,303,1213,0,1213],9612:[910,303,1212,0,606],9616:[910,303,1212,606,1212],9617:[860,258,1200,0,1200],9618:[874,273,1200,0,1200],9619:[874,273,1200,0,1200]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/Regular/BlockElements.js");

